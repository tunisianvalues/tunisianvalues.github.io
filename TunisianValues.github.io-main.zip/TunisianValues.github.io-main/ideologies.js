ideologies = [
  {
    name: "Ennahdha",
    stats: { econ: 60, dipl: 55, govt: 40, scty: 20 },
  },
  {
    name: "Nidaa Tounes (2014)",
    stats: { econ: 50, dipl: 60, govt: 35, scty: 40 },
  },
  {
    name: "Courant démocrate",
    stats: { econ: 65, dipl: 65, govt: 60, scty: 50 },
  },
  {
    name: "Parti destourien libre (PDL)",
    stats: { econ: 55, dipl: 50, govt: 25, scty: 35 },
  },
  {
    name: "Afek Tounes",
    stats: { econ: 30, dipl: 60, govt: 65, scty: 50 },
  },
  {
    name: "Al Joumhouri",
    stats: { econ: 55, dipl: 70, govt: 65, scty: 50 },
  },
  {
    name: "Ettakatol",
    stats: { econ: 65, dipl: 75, govt: 60, scty: 70 },
  },
  {
    name: "Mouvement Echaâb",
    stats: { econ: 70, dipl: 80, govt: 45, scty: 45 },
  },
  {
    name: "Parti Al Massar",
    stats: { econ: 60, dipl: 75, govt: 65, scty: 50 },
  },
  {
    name: "Parti nationaliste tunisien",
    stats: { econ: 45, dipl: 20, govt: 20, scty: 10 },
  },
  {
    name: "Parti des Travailleurs",
    stats: { econ: 90, dipl: 80, govt: 70, scty: 75 },
  },
  {
    name: "Al Karama",
    stats: { econ: 55, dipl: 35, govt: 25, scty: 15 },
  },
  {
    name: "Parti Baath tunisien",
    stats: { econ: 70, dipl: 90, govt: 10, scty: 30 },
  },
];
